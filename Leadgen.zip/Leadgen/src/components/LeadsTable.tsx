import { Phone, Mail, Copy, Check } from 'lucide-react';
import { useState } from 'react';
import type { Lead } from '@/lib/leadGenerator';

interface LeadsTableProps {
  leads: Lead[];
}

const CopyButton = ({ text }: { text: string }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (text === 'Not Available') return;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  if (text === 'Not Available') return null;

  return (
    <button
      onClick={handleCopy}
      className="ml-1.5 p-0.5 rounded text-muted-foreground hover:text-primary transition-colors"
      title="Copy"
    >
      {copied ? <Check className="h-3 w-3 text-accent" /> : <Copy className="h-3 w-3" />}
    </button>
  );
};

const LeadsTable = ({ leads }: LeadsTableProps) => {
  if (leads.length === 0) return null;

  return (
    <div className="w-full overflow-x-auto rounded-xl border border-border shadow-card bg-card">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border bg-secondary/50">
            <th className="text-left px-4 py-3 font-semibold text-foreground">#</th>
            <th className="text-left px-4 py-3 font-semibold text-foreground">Company Name</th>
            <th className="text-left px-4 py-3 font-semibold text-foreground">Phone</th>
            <th className="text-left px-4 py-3 font-semibold text-foreground">Email</th>
            <th className="text-left px-4 py-3 font-semibold text-foreground">Location</th>
            <th className="text-left px-4 py-3 font-semibold text-foreground">Source</th>
          </tr>
        </thead>
        <tbody>
          {leads.map((lead, i) => (
            <tr
              key={lead.id}
              className={`border-b border-border last:border-0 transition-colors duration-150 hover:bg-primary/[0.03] ${
                i % 2 === 0 ? 'bg-card' : 'bg-secondary/20'
              }`}
            >
              <td className="px-4 py-3 text-muted-foreground">{i + 1}</td>
              <td className="px-4 py-3 font-medium text-foreground">{lead.businessName}</td>
              <td className="px-4 py-3 text-foreground">
                <span className="inline-flex items-center">
                  <Phone className="h-3 w-3 mr-1.5 text-muted-foreground" />
                  {lead.phone}
                  <CopyButton text={lead.phone} />
                </span>
              </td>
              <td className="px-4 py-3">
                <span className="inline-flex items-center">
                  <Mail className="h-3 w-3 mr-1.5 text-muted-foreground" />
                  <span className={lead.email === 'Not Available' ? 'text-muted-foreground italic' : 'text-foreground'}>
                    {lead.email}
                  </span>
                  <CopyButton text={lead.email} />
                </span>
              </td>
              <td className="px-4 py-3 text-foreground">{lead.location}</td>
              <td className="px-4 py-3">
                <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-secondary text-xs text-secondary-foreground">
                  {lead.source}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default LeadsTable;
