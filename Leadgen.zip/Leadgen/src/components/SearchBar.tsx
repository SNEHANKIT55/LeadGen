import { useState, useCallback } from 'react';
import { Search, Zap } from 'lucide-react';

interface SearchBarProps {
  onSearch: (keyword: string) => void;
  isLoading: boolean;
  history: string[];
}

const SearchBar = ({ onSearch, isLoading, history }: SearchBarProps) => {
  const [keyword, setKeyword] = useState('');

  const handleSubmit = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault();
      if (keyword.trim()) onSearch(keyword.trim());
    },
    [keyword, onSearch]
  );

  const handleHistoryClick = (term: string) => {
    setKeyword(term);
    onSearch(term);
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="bg-card rounded-2xl shadow-search border border-border p-6 sm:p-8 transition-all duration-300">
        <label className="block text-sm font-medium text-muted-foreground mb-2">
          Enter Product or Service Keyword
        </label>
        <form onSubmit={handleSubmit} className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="e.g. Water Purifier Dealers, TDS Meter Suppliers…"
              className="w-full pl-10 pr-4 py-3 rounded-xl border border-input bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/30 focus:border-primary transition-all text-sm"
            />
          </div>
          <button
            type="submit"
            disabled={isLoading || !keyword.trim()}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-card hover:shadow-elevated"
          >
            {isLoading ? (
              <span className="h-4 w-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
            ) : (
              <Zap className="h-4 w-4" />
            )}
            Generate Leads
          </button>
        </form>

        {history.length > 0 && (
          <div className="mt-4 flex items-center gap-2 flex-wrap">
            <span className="text-xs text-muted-foreground">Recent:</span>
            {history.map((term) => (
              <button
                key={term}
                onClick={() => handleHistoryClick(term)}
                className="text-xs px-3 py-1 rounded-full bg-secondary text-secondary-foreground hover:bg-primary hover:text-primary-foreground transition-all duration-200"
              >
                {term}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchBar;
