export interface Lead {
  id: string;
  businessName: string;
  phone: string;
  email: string;
  location: string;
  source: string;
}

const prefixes = [
  'Smart', 'Pure', 'Pro', 'Tech', 'Clear', 'Ultra', 'Prime', 'Elite',
  'Aqua', 'Eco', 'Nova', 'Rapid', 'Max', 'Indo', 'Bharat', 'Global',
  'First', 'Royal', 'Star', 'Golden',
];

const suffixes = [
  'Solutions', 'Systems', 'Enterprises', 'Industries', 'Supplies',
  'Equipment', 'Services', 'Trading Co.', 'Works', 'Hub',
  'Tech', 'Corp', 'Group', 'Distributors', 'Agencies',
];

const cities = [
  'Mumbai', 'Pune', 'Delhi', 'Bangalore', 'Hyderabad',
  'Ahmedabad', 'Chennai', 'Kolkata', 'Nashik', 'Aurangabad',
  'Jaipur', 'Lucknow', 'Nagpur', 'Indore', 'Surat',
];

const sources = [
  'Google Maps', 'JustDial', 'Business Directory',
  'Website Listing', 'IndiaMart', 'TradeIndia',
];

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function generatePhone(): string {
  const second = [6, 7, 8, 9][Math.floor(Math.random() * 4)];
  let num = `+91 ${second}`;
  for (let i = 0; i < 9; i++) num += Math.floor(Math.random() * 10);
  return num;
}

function slugify(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 12);
}

export function generateLeads(keyword: string): Lead[] {
  const count = 10 + Math.floor(Math.random() * 11); // 10-20
  const words = keyword.trim().split(/\s+/);
  const keyPart = words[0] || 'Business';

  return Array.from({ length: count }, (_, i) => {
    const prefix = pick(prefixes);
    const suffix = pick(suffixes);
    const useKey = Math.random() > 0.4;
    const businessName = useKey
      ? `${prefix} ${keyPart} ${suffix}`
      : `${prefix}${pick(['Flow', 'Life', 'Drop', 'Wave', 'Line'])} ${suffix}`;

    const slug = slugify(businessName);
    const hasEmail = Math.random() > 0.25;
    const email = hasEmail
      ? `${['sales', 'info', 'contact', 'enquiry'][Math.floor(Math.random() * 4)]}@${slug}.com`
      : 'Not Available';

    return {
      id: `lead-${Date.now()}-${i}`,
      businessName,
      phone: generatePhone(),
      email,
      location: pick(cities),
      source: pick(sources),
    };
  });
}
