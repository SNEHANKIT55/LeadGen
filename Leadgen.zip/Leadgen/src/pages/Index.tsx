import { useState, useCallback } from 'react';
import { Zap, Download, Trash2, BarChart3 } from 'lucide-react';
import SearchBar from '@/components/SearchBar';
import LeadsTable from '@/components/LeadsTable';
import { generateLeads, type Lead } from '@/lib/leadGenerator';

const Index = () => {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [history, setHistory] = useState<string[]>([]);
  const [statusMsg, setStatusMsg] = useState('');

  const handleSearch = useCallback((keyword: string) => {
    setIsLoading(true);
    setStatusMsg('Searching business directories for leads…');
    setLeads([]);

    // Simulate network delay
    setTimeout(() => {
      const results = generateLeads(keyword);
      setLeads(results);
      setIsLoading(false);
      setStatusMsg(`${results.length} leads generated successfully`);

      setHistory((prev) => {
        const updated = [keyword, ...prev.filter((k) => k !== keyword)].slice(0, 3);
        return updated;
      });
    }, 1200 + Math.random() * 800);
  }, []);

  const handleExport = () => {
    const header = 'Company Name,Phone,Email,Location,Source';
    const rows = leads.map(
      (l) => `"${l.businessName}","${l.phone}","${l.email}","${l.location}","${l.source}"`
    );
    const csv = [header, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'leads.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleClear = () => {
    setLeads([]);
    setStatusMsg('');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
              <Zap className="h-4 w-4 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground leading-tight">LeadGen AI</h1>
              <p className="text-xs text-muted-foreground leading-tight hidden sm:block">
                Find business leads instantly from public directories
              </p>
            </div>
          </div>
          {leads.length > 0 && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-accent/10 text-accent">
              <BarChart3 className="h-3.5 w-3.5" />
              <span className="text-xs font-semibold">Total Leads: {leads.length}</span>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-8 sm:py-12 space-y-8">
        {/* Hero text */}
        <div className="text-center space-y-2 mb-2">
          <h2 className="text-2xl sm:text-3xl font-bold text-foreground">
            Generate Qualified Leads in Seconds
          </h2>
          <p className="text-muted-foreground text-sm max-w-md mx-auto">
            Enter a product or service keyword and get instant access to verified business contacts across India.
          </p>
        </div>

        <SearchBar onSearch={handleSearch} isLoading={isLoading} history={history} />

        {/* Status */}
        {statusMsg && (
          <div className="text-center">
            <p
              className={`inline-flex items-center gap-2 text-sm px-4 py-2 rounded-full ${
                isLoading
                  ? 'bg-primary/5 text-primary'
                  : 'bg-accent/10 text-accent'
              }`}
            >
              {isLoading && (
                <span className="h-3 w-3 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
              )}
              {statusMsg}
            </p>
          </div>
        )}

        {/* Action buttons */}
        {leads.length > 0 && (
          <div className="flex items-center justify-between flex-wrap gap-3">
            <p className="text-sm text-muted-foreground">
              Showing <span className="font-semibold text-foreground">{leads.length}</span> leads
            </p>
            <div className="flex gap-2">
              <button
                onClick={handleExport}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-border bg-card text-foreground text-sm font-medium hover:bg-secondary transition-colors shadow-card"
              >
                <Download className="h-4 w-4" />
                Export CSV
              </button>
              <button
                onClick={handleClear}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-border bg-card text-destructive text-sm font-medium hover:bg-destructive/5 transition-colors shadow-card"
              >
                <Trash2 className="h-4 w-4" />
                Clear
              </button>
            </div>
          </div>
        )}

        <LeadsTable leads={leads} />
      </main>
    </div>
  );
};

export default Index;
